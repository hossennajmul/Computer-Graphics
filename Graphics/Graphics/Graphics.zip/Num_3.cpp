//#include <stdio.h>
//#include <GL/glut.h>
//
//void myDisplay(void)
//{
//	glClear(GL_COLOR_BUFFER_BIT);
//	glColor3f(0.0, 0.0, 0.0);
//	glPointSize(4.0);
//
//	glColor3f(0.0, 0.5, 0.0);
//	glBegin(GL_LINE_LOOP);
//	glVertex2i(60, 0);
//	glVertex2i(0, 60);
//	glVertex2i(60, 120);
//	glVertex2i(120, 120);
//	glVertex2i(180, 60);
//	glVertex2i(120, 0);
//	glEnd();
//
//	glColor3f(1.0, 0.5, 0.0);
//	glBegin(GL_LINE_LOOP);
//	glVertex2i(70, 40);
//	glVertex2i(80, 80);
//	glVertex2i(90, 40);
//	glEnd();
//
//	glColor3f(0.0, 0.0, 0.0);
//	glBegin(GL_POINTS);
//	glVertex2i(90, 80);
//	glEnd();
//
//	glColor3f(1.0, 0.0, 0.0);
//	glBegin(GL_LINE_LOOP);
//	glVertex2i(100, 40);
//	glVertex2i(100, 80);
//	glVertex2i(130, 80);
//	glVertex2i(130, 40);
//	glEnd();
//
//	glFlush();
//}
//void myInit(void)
//{
//	glClearColor(1.0, 1.0, 1.0, 0.0);
//	glColor3f(0.0f, 0.0f, 0.0f);
//	glPointSize(4.0);
//	glMatrixMode(GL_PROJECTION);
//	glLoadIdentity();
//	gluOrtho2D(-200.0, 360.0, -360.0, 320.0);
//}
//void main(int argc, char** argv)
//{
//	glutInit(&argc, argv);
//	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
//	glutInitWindowSize(720, 580);
//	glutInitWindowPosition(100, 150);
//	glutCreateWindow("First Assignment Number 3");
//	glutDisplayFunc(myDisplay);
//	myInit();
//	glutMainLoop();
//}
