#include <GL/glut.h>

#include<iostream>
#include<math.h>
using namespace std;

void DDA(float x1, float y1, float x2, float y2)
{
	float x, y, x_inc = 0, y_inc = 0;
	float length = (x2 - x1);
	if ((y2 - y1) > length)
	{
		length = (y2 - y1);
	}
	x_inc = (x2 - x1) / length;
	y_inc = (y2 - y1) / length;
	x = x1 + .5;
	y = y1 + .5;
	for (int i = 1; i < length; i++)
	{
		glVertex2d(x, y);
		x = x + x_inc;
		y = y + y_inc;
	}
	glEnd();
	glFlush();
}

void myDisplay(void)
{
	float x, y, x1, x2, y1, y2;
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0.0, 0.0, 0.0);
	glPointSize(4.0);

	glColor3f(0.0, 0.0, 0.0);
	cout << "For Line Enter Initial Point (100,200) and Final point(200,300)\n";
	cout << "Enter initial point : \n";
	cin >> x1 >> y1;
	cout << "Enter Final point : \n";
	cin >> x2 >> y2;
	glBegin(GL_POINTS);
	DDA(x1, y1, x2, y2);
}
void Display_Bresenham()
{

}
void Display_Circle()
{

}
void Display_MPC()
{

}
void myInit(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glColor3f(0.0f, 0.0f, 0.0f);
	glPointSize(4.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, 720, 0, 630);
}
void main(int argc, char** argv)
{
	int choice;
	cout << "For DDA Algorithm Enter 1\n";
	cout << "For Bresenham Algorithm Enter 2\n";
	cout << "For Circle Algorithm Enter 3\n";
	cout << "For Mid Point Circle Algorithm Enter 4\n";
	cout << "For Exit Enter 5\n\n";
	cout << "Now Enter Your Coice : ";
	cin >> choice;
	
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(720, 480);
	glutInitWindowPosition(100, 150);
	glutCreateWindow("Mid Final Lab");
	switch (choice)
	{
	case 1:
		glutDisplayFunc(myDisplay);
		break;
	case 2:
		glutDisplayFunc(Display_Bresenham);
		break;
	case 3:
		glutDisplayFunc(Display_Circle);
		break;
	case 4:
		glutDisplayFunc(Display_MPC);
		break;
	case 5:
		break;
	default:
		exit;
	}
	myInit();
	glutMainLoop();
}