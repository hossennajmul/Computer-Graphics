//#include <GL/glut.h>
//#include <stdio.h>
//#include <math.h>
//
//void init(void)
//{
//	glClearColor(1.0, 1.0, 1.0, 0.0);
//	glMatrixMode(GL_PROJECTION);
//	gluOrtho2D(0.0, 200.0, 0.0, 200.0);
//}
//
//void setPixel(int x, GLint y)
//{
//	glBegin(GL_POINTS);
//	glVertex2i(x, y);
//	glEnd();
//}
//
//void Circle(){
//
//	int xCenter = 100, yCenter = 100, r = 50;
//	int x = 0, y = r;
//	int d = 3 / 2 - r;    // = 1 - r
//	glClear(GL_COLOR_BUFFER_BIT);
//	glColor3f(1, 0, 0);
//	while (x <= y){
//		setPixel(xCenter + x, yCenter + y);
//		setPixel(xCenter + y, yCenter + x);  //find other points by symmetry
//		setPixel(xCenter - x, yCenter + y);
//		setPixel(xCenter + y, yCenter - x);
//		setPixel(xCenter - x, yCenter - y);
//		setPixel(xCenter - y, yCenter - x);
//		setPixel(xCenter + x, yCenter - y);
//		setPixel(xCenter - y, yCenter + x);
//
//		if(d>0)
//		{
//			d = d + (2 * (x - y));
//			y--;
//		}
//		else
//			d = d + (2 * x) + 3;
//		x++;
//	}
//
//	glFlush();
//}
//
//int main(int argc, char **argv){
//	glutInit(&argc, argv);
//	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
//	glutInitWindowPosition(0, 0);
//	glutInitWindowSize(500, 500);
//	glutCreateWindow("Bresenham Circle");
//	init();
//	glutDisplayFunc(Circle);
//	glutMainLoop();
//	return 0;
//}