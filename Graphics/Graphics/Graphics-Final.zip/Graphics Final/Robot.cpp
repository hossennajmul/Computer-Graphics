//#include <stdio.h>
//#include <GL/glut.h>
//
//void myDisplay(void)
//{
//		glClear(GL_COLOR_BUFFER_BIT);
//		glColor3f(0.0, 0.0, 0.0);
//		glPointSize(4.0);
//
//		glColor3f(0.0, 0.0, 0.0);
//
//		glBegin(GL_QUADS);
//		glVertex2i(120, 120);
//		glVertex2i(120, 210);
//		glVertex2i(150, 210);
//		glVertex2i(150, 120);
//		glEnd();
//
//		glColor3f(0.043, 0.1059, 0.298);
//
//		glBegin(GL_QUADS);
//		glVertex2i(120, 210);
//		glVertex2i(120, 240);
//		glVertex2i(150, 240);
//		glVertex2i(150, 210);
//		glEnd();
//
//		glColor3f(0.976, 0.612, 0.196);
//
//		glBegin(GL_QUADS);
//		glVertex2i(120, 240);
//		glVertex2i(120, 270);
//		glVertex2i(150, 270);
//		glVertex2i(150, 240);
//		glEnd();
//
//		glColor3f(0.4, 0.4, 0.4);
//
//		glBegin(GL_QUADS);
//		glVertex2i(120, 270);
//		glVertex2i(120, 300);
//		glVertex2i(150, 300);
//		glVertex2i(150, 270);
//		glEnd();
//
//		glColor3f(0.0196, 0.047, 0.1216);
//
//		glBegin(GL_QUADS);
//		glVertex2i(150, 60);
//		glVertex2i(150, 90);
//		glVertex2i(180, 90);
//		glVertex2i(180, 60);
//		glEnd();
//
//		glColor3f(0.2, 0.2, 0.2);
//
//		glBegin(GL_QUADS);
//		glVertex2i(150, 90);
//		glVertex2i(150, 180);
//		glVertex2i(180, 180);
//		glVertex2i(180, 90);
//		glEnd();
//
//		glColor3f(0.0196, 0.047, 0.1216);
//
//		glBegin(GL_QUADS);
//		glVertex2i(150, 180);
//		glVertex2i(150, 210);
//		glVertex2i(180, 210);
//		glVertex2i(180, 180);
//		glEnd();
//
//		glColor3f(0.9922, 0.9334, 0.1294);
//
//		glBegin(GL_QUADS);
//		glVertex2i(150, 210);
//		glVertex2i(150, 240);
//		glVertex2i(300, 240);
//		glVertex2i(300, 210);
//		glEnd();
//
//		glColor3f(0.4, 0.4, 0.4);
//
//		glBegin(GL_QUADS);
//		glVertex2i(150, 240);
//		glVertex2i(150, 330);
//		glVertex2i(300, 330);
//		glVertex2i(300, 240);
//		glEnd();
//
//		glColor3f(0.043, 0.1059, 0.298);
//
//		glBegin(GL_QUADS);
//		glVertex2i(180, 60);
//		glVertex2i(180, 90);
//		glVertex2i(210, 90);
//		glVertex2i(210, 60);
//		glEnd();
//
//		glColor3f(0.4, 0.4, 0.4);
//
//		glBegin(GL_QUADS);
//		glVertex2i(180, 90);
//		glVertex2i(180, 150);
//		glVertex2i(210, 150);
//		glVertex2i(210, 90);
//		glEnd();
//
//		glColor3f(0.043, 0.1059, 0.298);
//
//		glBegin(GL_QUADS);
//		glVertex2i(180, 150);
//		glVertex2i(180, 210);
//		glVertex2i(270, 210);
//		glVertex2i(270, 150);
//		glEnd();
//
//		glColor3f(0.2, 0.2, 0.2);
//
//		glBegin(GL_QUADS);
//		glVertex2i(180, 270);
//		glVertex2i(180, 300);
//		glVertex2i(270, 300);
//		glVertex2i(270, 270);
//		glEnd();
//
//		glColor3f(0.6784, 0.4, 0.0549);
//
//		glBegin(GL_QUADS);
//		glVertex2i(180, 330);
//		glVertex2i(180, 360);
//		glVertex2i(210, 360);
//		glVertex2i(210, 330);
//		glEnd();
//
//		glColor3f(0.0196, 0.047, 0.1216);
//
//		glBegin(GL_QUADS);
//		glVertex2i(180, 360);
//		glVertex2i(180, 450);
//		glVertex2i(210, 450);
//		glVertex2i(210, 360);
//		glEnd();
//
//		glColor3f(0, 0, 0);
//
//		glBegin(GL_QUADS);
//		glVertex2i(210, 120);
//		glVertex2i(210, 150);
//		glVertex2i(240, 150);
//		glVertex2i(240, 120);
//		glEnd();
//
//		glColor3f(0.976, 0.612, 0.196);
//
//		glBegin(GL_QUADS);
//		glVertex2i(210, 330);
//		glVertex2i(210, 360);
//		glVertex2i(270, 360);
//		glVertex2i(270, 330);
//		glEnd();
//
//		glColor3f(0.976, 0.612, 0.196);
//
//		glBegin(GL_QUADS);
//		glVertex2i(210, 330);
//		glVertex2i(210, 360);
//		glVertex2i(270, 360);
//		glVertex2i(270, 330);
//		glEnd();
//
//		glColor3f(0.043, 0.1059, 0.298);
//
//		glBegin(GL_QUADS);
//		glVertex2i(210, 360);
//		glVertex2i(210, 420);
//		glVertex2i(270, 420);
//		glVertex2i(270, 360);
//		glEnd();
//
//		glColor3f(0.043, 0.1059, 0.298);
//
//		glBegin(GL_QUADS);
//		glVertex2i(240, 420);
//		glVertex2i(240, 450);
//		glVertex2i(270, 450);
//		glVertex2i(270, 420);
//		glEnd();
//
//		glColor3f(0.0196, 0.047, 0.1216);
//
//		glBegin(GL_QUADS);
//		glVertex2i(240, 60);
//		glVertex2i(240, 90);
//		glVertex2i(270, 90);
//		glVertex2i(270, 60);
//		glEnd();
//
//		glColor3f(0.2, 0.2, 0.2);
//
//		glBegin(GL_QUADS);
//		glVertex2i(240, 90);
//		glVertex2i(240, 150);
//		glVertex2i(270, 150);
//		glVertex2i(270, 90);
//		glEnd();
//
//		glColor3f(0.043, 0.1059, 0.298);
//
//		glBegin(GL_QUADS);
//		glVertex2i(270, 60);
//		glVertex2i(270, 90);
//		glVertex2i(300, 90);
//		glVertex2i(300, 60);
//		glEnd();
//		
//		glColor3f(0.4, 0.4, 0.4);
//
//		glBegin(GL_QUADS);
//		glVertex2i(270, 90);
//		glVertex2i(270, 180);
//		glVertex2i(300, 180);
//		glVertex2i(300, 90);
//		glEnd();
//
//		glColor3f(0.043, 0.1059, 0.298);
//
//		glBegin(GL_QUADS);
//		glVertex2i(270, 180);
//		glVertex2i(270, 210);
//		glVertex2i(300, 210);
//		glVertex2i(300, 180);
//		glEnd();
//
//		 glColor3f(0.4, 0.4, 0.4);
//
//		glBegin(GL_QUADS);
//		glVertex2i(270, 90);
//		glVertex2i(270, 180);
//		glVertex2i(300, 180);
//		glVertex2i(300, 90);
//		glEnd();
//
//		glColor3f(0, 0, 0);
//
//		glBegin(GL_QUADS);
//		glVertex2i(300, 120);
//		glVertex2i(300, 210);
//		glVertex2i(330, 210);
//		glVertex2i(330, 120);
//		glEnd();
//
//		glColor3f(0.043, 0.1059, 0.298);
//
//		glBegin(GL_QUADS);
//		glVertex2i(300, 210);
//		glVertex2i(300, 240);
//		glVertex2i(330, 240);
//		glVertex2i(330, 210);
//		glEnd();
//
//		glColor3f(0.976, 0.612, 0.196);
//
//		glBegin(GL_QUADS);
//		glVertex2i(300, 240);
//		glVertex2i(300, 270);
//		glVertex2i(330, 270);
//		glVertex2i(330, 240);
//		glEnd();
//
//		glColor3f(0.4, 0.4, 0.4);
//
//		glBegin(GL_QUADS);
//		glVertex2i(300, 270);
//		glVertex2i(300, 300);
//		glVertex2i(330, 300);
//		glVertex2i(330, 270);
//		glEnd();
//
//		//////2nd Robot//////
//
//
//		glColor3f(0.8196, 0.749, 0.1137);
//
//		glBegin(GL_QUADS);
//		glVertex2i(420, 120);
//		glVertex2i(420, 210);
//		glVertex2i(450, 210);
//		glVertex2i(450, 120);
//		glEnd();
//
//		glColor3f(0.6784, 0.4, 0.0549);
//
//		glBegin(GL_QUADS);
//		glVertex2i(420, 210);
//		glVertex2i(420, 240);
//		glVertex2i(450, 240);
//		glVertex2i(450, 210);
//		glEnd();
//
//		glColor3f(0.976, 0.612, 0.196);
//
//		glBegin(GL_QUADS);
//		glVertex2i(420, 240);
//		glVertex2i(420, 270);
//		glVertex2i(450, 270);
//		glVertex2i(450, 240);
//		glEnd();
//
//		glColor3f(0.0549, 0.2353, 0.1216);
//
//		glBegin(GL_QUADS);
//		glVertex2i(420, 270);
//		glVertex2i(420, 300);
//		glVertex2i(450, 300);
//		glVertex2i(450, 270);
//		glEnd();
//
//		glColor3f(0.0549, 0.2353, 0.1216);
//
//		glBegin(GL_QUADS);
//		glVertex2i(450, 60);
//		glVertex2i(450, 90);
//		glVertex2i(480, 90);
//		glVertex2i(480, 60);
//		glEnd();
//
//		glColor3f(0.6784, 0.4, 0.0549);
//
//		glBegin(GL_QUADS);
//		glVertex2i(450, 90);
//		glVertex2i(450, 180);
//		glVertex2i(480, 180);
//		glVertex2i(480, 90);
//		glEnd();
//
//		glColor3f(0.0824, 0.4118, 0.2157);
//
//		glBegin(GL_QUADS);
//		glVertex2i(450, 180);
//		glVertex2i(450, 210);
//		glVertex2i(600, 210);
//		glVertex2i(600, 180);
//		glEnd();
//
//		glColor3f(0.9922, 0.9334, 0.1294);
//
//		glBegin(GL_QUADS);
//		glVertex2i(450, 210);
//		glVertex2i(450, 240);
//		glVertex2i(600, 240);
//		glVertex2i(600, 210);
//		glEnd();
//
//		glColor3f(0.5569, 0.0824, 0.1176);
//
//		glBegin(GL_QUADS);
//		glVertex2i(450, 240);
//		glVertex2i(450, 330);
//		glVertex2i(480, 330);
//		glVertex2i(480, 240);
//		glEnd();
//
//		glColor3f(0.0824, 0.4118, 0.2157);
//
//		glBegin(GL_QUADS);
//		glVertex2i(480, 60);
//		glVertex2i(480, 90);
//		glVertex2i(510, 90);
//		glVertex2i(510, 60);
//		glEnd();
//
//		glColor3f(0.976, 0.612, 0.196);
//
//		glBegin(GL_QUADS);
//		glVertex2i(480, 90);
//		glVertex2i(480, 150);
//		glVertex2i(510, 150);
//		glVertex2i(510, 90);
//		glEnd();
//
//		glColor3f(0.0824, 0.4118, 0.2157);
//
//		glBegin(GL_QUADS);
//		glVertex2i(480, 150);
//		glVertex2i(480, 180);
//		glVertex2i(570, 180);
//		glVertex2i(570, 150);
//		glEnd();
//
//		glColor3f(0.9216, 0.1098, 0.1412);
//
//		glBegin(GL_QUADS);
//		glVertex2i(480, 240);
//		glVertex2i(480, 330);
//		glVertex2i(600, 330);
//		glVertex2i(600, 240);
//		glEnd();
//
//		glColor3f(0.8196, 0.749, 0.1137);
//
//		glBegin(GL_QUADS);
//		glVertex2i(480, 330);
//		glVertex2i(480, 360);
//		glVertex2i(510, 360);
//		glVertex2i(510, 330);
//		glEnd();
//
//		glColor3f(0.6784, 0.4, 0.0549);
//
//		glBegin(GL_QUADS);
//		glVertex2i(480, 360);
//		glVertex2i(480, 390);
//		glVertex2i(510, 390);
//		glVertex2i(510, 360);
//		glEnd();
//
//		glColor3f(0.098, 0.098, 0.098);
//
//		glBegin(GL_QUADS);
//		glVertex2i(480, 390);
//		glVertex2i(480, 420);
//		glVertex2i(570, 420);
//		glVertex2i(570, 390);
//		glEnd();
//
//		glColor3f(0.8196, 0.749, 0.1137);
//
//		glBegin(GL_QUADS);
//		glVertex2i(510, 120);
//		glVertex2i(510, 150);
//		glVertex2i(540, 150);
//		glVertex2i(540, 120);
//		glEnd();
//
//		glColor3f(0, 0, 0);
//
//		glBegin(GL_QUADS);
//		glVertex2i(540, 270);
//		glVertex2i(540, 300);
//		glVertex2i(570, 300);
//		glVertex2i(570, 270);
//		glEnd();
//
//		glColor3f(0.976, 0.612, 0.196);
//
//		glBegin(GL_QUADS);
//		glVertex2i(510, 330);
//		glVertex2i(510, 390);
//		glVertex2i(540, 390);
//		glVertex2i(540, 330);
//		glEnd();
//
//		glColor3f(0.0549, 0.2353, 0.1216);
//
//		glBegin(GL_QUADS);
//		glVertex2i(540, 60);
//		glVertex2i(540, 90);
//		glVertex2i(570, 90);
//		glVertex2i(570, 60);
//		glEnd();
//
//		glColor3f(0.6784, 0.4, 0.0549);
//
//		glBegin(GL_QUADS);
//		glVertex2i(540, 90);
//		glVertex2i(540, 150);
//		glVertex2i(570, 150);
//		glVertex2i(570, 90);
//		glEnd();
//
//		glColor3f(0.9922, 0.9334, 0.1294);
//
//		glBegin(GL_QUADS);
//		glVertex2i(540, 330);
//		glVertex2i(540, 360);
//		glVertex2i(570, 360);
//		glVertex2i(570, 330);
//		glEnd();
//
//		glColor3f(0.976, 0.612, 0.196);
//
//		glBegin(GL_QUADS);
//		glVertex2i(540, 360);
//		glVertex2i(540, 390);
//		glVertex2i(570, 390);
//		glVertex2i(570, 360);
//		glEnd();
//
//		glColor3f(0.0824, 0.4118, 0.2157);
//
//		glBegin(GL_QUADS);
//		glVertex2i(570, 60);
//		glVertex2i(570, 90);
//		glVertex2i(600, 90);
//		glVertex2i(600, 60);
//		glEnd();
//
//		glColor3f(0.976, 0.612, 0.196);
//
//		glBegin(GL_QUADS);
//		glVertex2i(570, 90);
//		glVertex2i(570, 180);
//		glVertex2i(600, 180);
//		glVertex2i(600, 90);
//		glEnd();
//
//		glColor3f(0.8196, 0.749, 0.1137);
//
//		glBegin(GL_QUADS);
//		glVertex2i(600, 120);
//		glVertex2i(600, 210);
//		glVertex2i(630, 210);
//		glVertex2i(630, 120);
//		glEnd();
//
//		glColor3f(0.6784, 0.4, 0.0549);
//
//		glBegin(GL_QUADS);
//		glVertex2i(600, 210);
//		glVertex2i(600, 240);
//		glVertex2i(630, 240);
//		glVertex2i(630, 210);
//		glEnd();
//
//		glColor3f(0.976, 0.612, 0.196);
//
//		glBegin(GL_QUADS);
//		glVertex2i(600, 240);
//		glVertex2i(600, 270);
//		glVertex2i(630, 270);
//		glVertex2i(630, 240);
//		glEnd();
//
//		glColor3f(0.0824, 0.4118, 0.2157);
//
//		glBegin(GL_QUADS);
//		glVertex2i(600, 270);
//		glVertex2i(600, 300);
//		glVertex2i(630, 300);
//		glVertex2i(630, 270);
//		glEnd();
//
//
//		glFlush();
//	
//}
//void myInit(void)
//{
//	glClearColor(1.0, 1.0, 1.0, 0.0);
//	glColor3f(0.0f, 0.0f, 0.0f);
//	glPointSize(4.0);
//	glMatrixMode(GL_PROJECTION);
//	glLoadIdentity();
//	gluOrtho2D(0, 720, 0, 630);
//}
//void main(int argc, char** argv)
//{
//	glutInit(&argc, argv);
//	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
//	glutInitWindowSize(720, 480);
//	glutInitWindowPosition(100, 150);
//	glutCreateWindow("ROBOT");
//	glutDisplayFunc(myDisplay);
//	myInit();
//	glutMainLoop();
//}
