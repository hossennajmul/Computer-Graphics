//#include <stdio.h>
//#include <GL/glut.h>
//
//void myDisplay(void)
//{
//	glClear(GL_COLOR_BUFFER_BIT);
//	glColor3f(0.0, 0.0, 0.0);
//	glPointSize(4.0);
//
//	glColor3f(0.0, 0.5, 0.0);
//	glBegin(GL_LINE_LOOP);
//	glVertex2i(100, 0);
//	glVertex2i(0, 100);
//	glVertex2i(0, 200);
//	glVertex2i(100, 300);
//	glVertex2i(200, 300);
//	glVertex2i(300, 200);
//	glVertex2i(300, 100);
//	glVertex2i(200, 0);
//	glEnd();
//
//	glColor3f(1.0, 0.0, 0.0);
//	glBegin(GL_QUADS);
//	glVertex2i(140, 140);
//	glVertex2i(140, 170);
//	glVertex2i(160, 170);
//	glVertex2i(160, 140);
//	glEnd();
//
//	glColor3f(1.0, 0.5, 0.0);
//	glBegin(GL_LINE_STRIP);
//	glVertex2i(140, 155);
//	glVertex2i(80, 95);
//	glVertex2i(80, 70);
//	glVertex2i(140, 140);
//	glEnd();
//
//	glColor3f(1.0, 0.5, 0.0);
//	glBegin(GL_LINE_STRIP);
//	glVertex2i(145, 170);
//	glVertex2i(145, 260);
//	glVertex2i(155, 260);
//	glVertex2i(155, 170);
//	glEnd();
//
//	glColor3f(1.0, 0.5, 0.0);
//	glBegin(GL_LINE_STRIP);
//	glVertex2i(160, 155);
//	glVertex2i(225, 80);
//	glVertex2i(225, 70);
//	glVertex2i(215, 70);
//	glVertex2i(160, 140);
//	glEnd();
//
//	glColor3f(0.0, 0.5, 0.0);
//	glBegin(GL_LINES);
//	glVertex2i(80, 85);
//	glVertex2i(60, 65);
//	glEnd();
//
//	glColor3f(0.0, 0.5, 0.0);
//	glBegin(GL_LINE_LOOP);
//	glVertex2i(130, 260);
//	glVertex2i(150, 290);
//	glVertex2i(170, 260);
//	glEnd();
//
//	glFlush();
//}
//void myInit(void)
//{
//	glClearColor(1.0, 1.0, 1.0, 0.0);
//	glColor3f(0.0f, 0.0f, 0.0f);
//	glPointSize(4.0);
//	glMatrixMode(GL_PROJECTION);
//	glLoadIdentity();
//	gluOrtho2D(-200.0, 450.0, -360.0, 550.0);
//}
//void main(int argc, char** argv)
//{
//	glutInit(&argc, argv);
//	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
//	glutInitWindowSize(720, 580);
//	glutInitWindowPosition(50, 50);
//	glutCreateWindow("First Assignment Number 4");
//	glutDisplayFunc(myDisplay);
//	myInit();
//	glutMainLoop();
//}
