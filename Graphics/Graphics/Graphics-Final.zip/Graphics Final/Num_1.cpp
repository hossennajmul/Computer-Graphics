//#include <stdio.h>
//#include <GL/glut.h>
//
//void myDisplay(void)
//{
//	glClear(GL_COLOR_BUFFER_BIT);
//	glColor3f(0.0, 0.0, 0.0);
//	glPointSize(4.0);
//
//	glColor3f(0.0, 0.5, 0.0);
//	glBegin(GL_LINE_LOOP);
//	glVertex2i(0, 0);
//	glVertex2i(0, 100);
//	glVertex2i(150, 100);
//	glVertex2i(150, 0);
//	glEnd();
//
//	glColor3f(0.0, 0.5, 0.0);
//	glBegin(GL_LINES);
//	glVertex2i(0, 0);
//	glVertex2i(150, 100);
//	glEnd();
//
//	glColor3f(0.0, 0.5, 0.0);
//	glBegin(GL_LINES);
//	glVertex2i(0, 100);
//	glVertex2i(150, 0);
//	glEnd();
//
//	glFlush();
//}
//void myInit(void)
//{
//	glClearColor(1.0, 1.0, 1.0, 0.0);
//	glColor3f(0.0f, 0.0f, 0.0f);
//	glPointSize(4.0);
//	glMatrixMode(GL_PROJECTION);
//	glLoadIdentity();
//	gluOrtho2D(-200.0, 360.0, -360.0, 320.0);
//}
//void main(int argc, char** argv)
//{
//	glutInit(&argc, argv);
//	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
//	glutInitWindowSize(720, 580);
//	glutInitWindowPosition(100, 150);
//	glutCreateWindow("First Assignment Number 1");
//	glutDisplayFunc(myDisplay);
//	myInit();
//	glutMainLoop();
//}
#include <GL/glut.h>
#include <stdio.h>
#include <math.h>

void init(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0.0, 200.0, 0.0, 200.0);
}

void setPixel(GLint x, GLint y)
{
	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
}

void Circle(){

	int xCenter = 100, yCenter = 100, r = 50;
	int x = 0, y = r;
	int d = 3 / 2 - r;    // = 1 - r
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1, 0, 0);
	while (x <= y){
		setPixel(xCenter + x, yCenter + y);
		setPixel(xCenter + y, yCenter + x);  //find other points by symmetry
		setPixel(xCenter - x, yCenter + y);
		setPixel(xCenter + y, yCenter - x);
		setPixel(xCenter - x, yCenter - y);
		setPixel(xCenter - y, yCenter - x);
		setPixel(xCenter + x, yCenter - y);
		setPixel(xCenter - y, yCenter + x);

		if (d<0)
			d += (2 * x) + 3;
		else {
			d += (2 * (x - y)) + 5;
			y -= 1;
		}
		x++;
	}

	glFlush();
}

int main(int argc, char **argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowPosition(0, 0);
	glutInitWindowSize(500, 500);
	glutCreateWindow("Bresenham Circle");
	init();
	glutDisplayFunc(Circle);
	glutMainLoop();
	return 0;
}